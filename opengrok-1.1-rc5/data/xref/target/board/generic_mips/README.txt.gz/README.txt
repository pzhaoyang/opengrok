<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [];} /* ]]> */</script><a class="l" name="1" href="#1">1</a>The "generic_mips" product defines a MIPS based non-hardware-specific
<a class="l" name="2" href="#2">2</a>target without a kernel or bootloader.
<a class="l" name="3" href="#3">3</a>
<a class="l" name="4" href="#4">4</a>It can be used to build the entire user-level system, and
<a class="l" name="5" href="#5">5</a>will work with the emulator, though sound will not work
<a class="l" name="6" href="#6">6</a>(see the "emulator" product for that).
<a class="l" name="7" href="#7">7</a>
<a class="l" name="8" href="#8">8</a>It is not a product "base class"; no other products inherit
<a class="l" name="9" href="#9">9</a>from it or use it in any way.
<a class="hl" name="10" href="#10">10</a>