<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Function","xf",[["check_builds",71],["compare_builds",59],["diff_builds",78],["do_builds",36],["golden_builds",53]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class="c"># Copyright (C) 2009 The Android Open Source Project</span>
<a class="l" name="2" href="#2">2</a><span class="c">#</span>
<a class="l" name="3" href="#3">3</a><span class="c"># Licensed under the Apache License, Version 2.0 (the 'License');</span>
<a class="l" name="4" href="#4">4</a><span class="c"># you may not use this file except in compliance with the License.</span>
<a class="l" name="5" href="#5">5</a><span class="c"># You may obtain a copy of the License at</span>
<a class="l" name="6" href="#6">6</a><span class="c">#</span>
<a class="l" name="7" href="#7">7</a><span class="c">#      <a href="http://www.apache.org/licenses/LICENSE-2.0">http://www.apache.org/licenses/LICENSE-2.0</a></span>
<a class="l" name="8" href="#8">8</a><span class="c">#</span>
<a class="l" name="9" href="#9">9</a><span class="c"># Unless required by applicable law or agreed to in writing, software</span>
<a class="hl" name="10" href="#10">10</a><span class="c"># distributed under the License is distributed on an 'AS IS' BASIS,</span>
<a class="l" name="11" href="#11">11</a><span class="c"># WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.</span>
<a class="l" name="12" href="#12">12</a><span class="c"># See the License for the specific language governing permissions and</span>
<a class="l" name="13" href="#13">13</a><span class="c"># limitations under the License.</span>
<a class="l" name="14" href="#14">14</a>
<a class="l" name="15" href="#15">15</a><span class="c">#</span>
<a class="l" name="16" href="#16">16</a><span class="c"># Usage:</span>
<a class="l" name="17" href="#17">17</a><span class="c">#</span>
<a class="l" name="18" href="#18">18</a><span class="c"># Source this file into your environment.  Then:</span>
<a class="l" name="19" href="#19">19</a><span class="c">#</span>
<a class="hl" name="20" href="#20">20</a><span class="c">#    $ golden_builds sdk-sdk generic-eng generic-userdebug dream-eng</span>
<a class="l" name="21" href="#21">21</a><span class="c"># </span>
<a class="l" name="22" href="#22">22</a><span class="c"># will build a set of combos.  This might take a while.  Then you can</span>
<a class="l" name="23" href="#23">23</a><span class="c"># go make changes, and run:</span>
<a class="l" name="24" href="#24">24</a><span class="c">#</span>
<a class="l" name="25" href="#25">25</a><span class="c">#    $ check_builds sdk-sdk generic-eng generic-userdebug dream-eng</span>
<a class="l" name="26" href="#26">26</a><span class="c">#</span>
<a class="l" name="27" href="#27">27</a><span class="c"># Go get dinner, and when you get back, there will be a file</span>
<a class="l" name="28" href="#28">28</a><span class="c"># <a href="/source/s?path=test-builds/">test-builds</a>/<a href="/source/s?path=test-builds/sizes.html">sizes.html</a> that has a pretty chart of which files are</span>
<a class="l" name="29" href="#29">29</a><span class="c"># in which tree, and how big they are.  In that chart, cells for files</span>
<a class="hl" name="30" href="#30">30</a><span class="c"># that are missing are red, and rows where the file sizes are not all</span>
<a class="l" name="31" href="#31">31</a><span class="c"># the same will be blue.</span>
<a class="l" name="32" href="#32">32</a><span class="c">#</span>
<a class="l" name="33" href="#33">33</a>
<a class="l" name="34" href="#34">34</a><a href="/source/s?defs=TEST_BUILD_DIR&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">TEST_BUILD_DIR</a>=<b>test</b>-<a href="/source/s?defs=builds&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">builds</a>
<a class="l" name="35" href="#35">35</a>
<a class="l" name="36" href="#36">36</a><b>function</b> <a class="xf" name="do_builds"/><a href="/source/s?refs=do_builds&amp;project=tools" class="xf intelliWindow-symbol" data-definition-place="def">do_builds</a>
<a class="l" name="37" href="#37">37</a><span>{
<a class="l" name="38" href="#38">38</a>    <a href="/source/s?defs=PREFIX&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">PREFIX</a>=$<span class="n">1</span>
<a class="l" name="39" href="#39">39</a>    <b>shift</b>
<a class="hl" name="40" href="#40">40</a>    <b>while</b> [ -n </span><span class="s">"$1"</span><span> ]
<a class="l" name="41" href="#41">41</a>    <b>do</b>
<a class="l" name="42" href="#42">42</a>        <a href="/source/s?defs=rm&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">rm</a> -<a href="/source/s?defs=rf&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">rf</a> <a href="/source/s?defs=$TEST_BUILD_DIR&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">$TEST_BUILD_DIR</a>/<a href="/source/s?defs=$PREFIX&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">$PREFIX</a>-$<span class="n">1</span>
<a class="l" name="43" href="#43">43</a>        <a href="/source/s?defs=make&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">make</a> <a href="/source/s?defs=PRODUCT&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">PRODUCT</a>-</span><span>$(<b>echo</b> $<span class="n">1</span> | <a href="/source/s?defs=sed&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">sed</a> </span><span class="s">"s/-.*//"</span><span> )</span><span>-<a href="/source/s?defs=installclean&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">installclean</a>
<a class="l" name="44" href="#44">44</a>        <a href="/source/s?defs=make&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">make</a> -<a href="/source/s?defs=j16&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">j16</a> <a href="/source/s?defs=PRODUCT&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">PRODUCT</a>-$<span class="n">1</span> <a href="/source/s?defs=dist&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">dist</a> <a href="/source/s?defs=DIST_DIR&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">DIST_DIR</a>=<a href="/source/s?defs=$TEST_BUILD_DIR&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">$TEST_BUILD_DIR</a>/<a href="/source/s?defs=$PREFIX&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">$PREFIX</a>-$<span class="n">1</span>
<a class="l" name="45" href="#45">45</a>        <b>if</b> [ $? -<a href="/source/s?defs=ne&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ne</a> <span class="n">0</span> ] ; <b>then</b>
<a class="l" name="46" href="#46">46</a>            <b>echo</b> <a href="/source/s?defs=FAILED&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">FAILED</a>
<a class="l" name="47" href="#47">47</a>            <b>return</b>
<a class="l" name="48" href="#48">48</a>        <b>fi</b>
<a class="l" name="49" href="#49">49</a>        <b>shift</b>
<a class="hl" name="50" href="#50">50</a>    <b>done</b>
<a class="l" name="51" href="#51">51</a>}</span>
<a class="l" name="52" href="#52">52</a>
<a class="l" name="53" href="#53">53</a><b>function</b> <a class="xf" name="golden_builds"/><a href="/source/s?refs=golden_builds&amp;project=tools" class="xf intelliWindow-symbol" data-definition-place="def">golden_builds</a>
<a class="l" name="54" href="#54">54</a><span>{
<a class="l" name="55" href="#55">55</a>    <a href="/source/s?defs=rm&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">rm</a> -<a href="/source/s?defs=rf&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">rf</a> <a href="/source/s?defs=$TEST_BUILD_DIR&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">$TEST_BUILD_DIR</a>/<a href="/source/s?defs=golden&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">golden</a>-* <a href="/source/s?defs=$TEST_BUILD_DIR&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">$TEST_BUILD_DIR</a>/<a href="/source/s?defs=dist&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">dist</a>-*
<a class="l" name="56" href="#56">56</a>    <a class="d intelliWindow-symbol" href="#do_builds" data-definition-place="defined-in-file">do_builds</a> <a href="/source/s?defs=golden&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">golden</a> </span><span class="s">"$@"</span><span>
<a class="l" name="57" href="#57">57</a>}</span>
<a class="l" name="58" href="#58">58</a>
<a class="l" name="59" href="#59">59</a><b>function</b> <a class="xf" name="compare_builds"/><a href="/source/s?refs=compare_builds&amp;project=tools" class="xf intelliWindow-symbol" data-definition-place="def">compare_builds</a>
<a class="hl" name="60" href="#60">60</a><span>{
<a class="l" name="61" href="#61">61</a>    <b>local</b> <a href="/source/s?defs=inputs&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">inputs</a>=
<a class="l" name="62" href="#62">62</a>    <b>while</b> [ -n </span><span class="s">"$1"</span><span> ]
<a class="l" name="63" href="#63">63</a>    <b>do</b>
<a class="l" name="64" href="#64">64</a>        <a href="/source/s?defs=inputs&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">inputs</a>=</span><span class="s">"<a href="/source/s?refs=$inputs&amp;project=tools">$inputs</a> <a href="/source/s?refs=$TEST_BUILD_DIR&amp;project=tools">$TEST_BUILD_DIR</a>/golden-$1/<a href="/source/s?path=installed-files.txt&amp;project=tools">installed-files.txt</a>"</span><span>
<a class="l" name="65" href="#65">65</a>        <a href="/source/s?defs=inputs&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">inputs</a>=</span><span class="s">"<a href="/source/s?refs=$inputs&amp;project=tools">$inputs</a> <a href="/source/s?refs=$TEST_BUILD_DIR&amp;project=tools">$TEST_BUILD_DIR</a>/dist-$1/<a href="/source/s?path=installed-files.txt&amp;project=tools">installed-files.txt</a>"</span><span>
<a class="l" name="66" href="#66">66</a>        <b>shift</b>
<a class="l" name="67" href="#67">67</a>    <b>done</b>
<a class="l" name="68" href="#68">68</a>    <a href="/source/s?path=build/">build</a>/<a href="/source/s?path=build/tools/">tools</a>/<a href="/source/s?path=build/tools/compare_fileslist.py">compare_fileslist.py</a> <a href="/source/s?defs=$inputs&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">$inputs</a> &gt; <a href="/source/s?defs=$TEST_BUILD_DIR&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">$TEST_BUILD_DIR</a>/<a href="/source/s?path=sizes.html&amp;project=tools">sizes.html</a>
<a class="l" name="69" href="#69">69</a>}</span>
<a class="hl" name="70" href="#70">70</a>
<a class="l" name="71" href="#71">71</a><b>function</b> <a class="xf" name="check_builds"/><a href="/source/s?refs=check_builds&amp;project=tools" class="xf intelliWindow-symbol" data-definition-place="def">check_builds</a>
<a class="l" name="72" href="#72">72</a><span>{
<a class="l" name="73" href="#73">73</a>    <a href="/source/s?defs=rm&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">rm</a> -<a href="/source/s?defs=rf&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">rf</a> <a href="/source/s?defs=$TEST_BUILD_DIR&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">$TEST_BUILD_DIR</a>/<a href="/source/s?defs=dist&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">dist</a>-*
<a class="l" name="74" href="#74">74</a>    <a class="d intelliWindow-symbol" href="#do_builds" data-definition-place="defined-in-file">do_builds</a> <a href="/source/s?defs=dist&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">dist</a> </span><span class="s">"$@"</span><span>
<a class="l" name="75" href="#75">75</a>    <a class="d intelliWindow-symbol" href="#compare_builds" data-definition-place="defined-in-file">compare_builds</a> </span><span class="s">"$@"</span><span>
<a class="l" name="76" href="#76">76</a>}</span>
<a class="l" name="77" href="#77">77</a>
<a class="l" name="78" href="#78">78</a><b>function</b> <a class="xf" name="diff_builds"/><a href="/source/s?refs=diff_builds&amp;project=tools" class="xf intelliWindow-symbol" data-definition-place="def">diff_builds</a>
<a class="l" name="79" href="#79">79</a><span>{
<a class="hl" name="80" href="#80">80</a>    <b>local</b> <a href="/source/s?defs=inputs&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">inputs</a>=
<a class="l" name="81" href="#81">81</a>    <b>while</b> [ -n </span><span class="s">"$1"</span><span> ]
<a class="l" name="82" href="#82">82</a>    <b>do</b>
<a class="l" name="83" href="#83">83</a>        <a href="/source/s?defs=diff&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">diff</a> <a href="/source/s?defs=$TEST_BUILD_DIR&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">$TEST_BUILD_DIR</a>/<a href="/source/s?defs=golden&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">golden</a>-$<span class="n">1</span>/<a href="/source/s?path=installed-files.txt&amp;project=tools">installed-files.txt</a> <a href="/source/s?defs=$TEST_BUILD_DIR&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">$TEST_BUILD_DIR</a>/<a href="/source/s?defs=dist&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">dist</a>-$<span class="n">1</span>/<a href="/source/s?path=installed-files.txt&amp;project=tools">installed-files.txt</a> &amp;&gt; /<a href="/source/s?path=/dev/">dev</a>/<a href="/source/s?path=/dev/null">null</a>
<a class="l" name="84" href="#84">84</a>        <b>if</b> [ $? != <span class="n">0</span> ]; <b>then</b>
<a class="l" name="85" href="#85">85</a>            <b>echo</b> =========== $<span class="n">1</span> ===========
<a class="l" name="86" href="#86">86</a>            <a href="/source/s?defs=diff&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">diff</a> <a href="/source/s?defs=$TEST_BUILD_DIR&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">$TEST_BUILD_DIR</a>/<a href="/source/s?defs=golden&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">golden</a>-$<span class="n">1</span>/<a href="/source/s?path=installed-files.txt&amp;project=tools">installed-files.txt</a> <a href="/source/s?defs=$TEST_BUILD_DIR&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">$TEST_BUILD_DIR</a>/<a href="/source/s?defs=dist&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">dist</a>-$<span class="n">1</span>/<a href="/source/s?path=installed-files.txt&amp;project=tools">installed-files.txt</a>
<a class="l" name="87" href="#87">87</a>        <b>fi</b>
<a class="l" name="88" href="#88">88</a>        <b>shift</b>
<a class="l" name="89" href="#89">89</a>    <b>done</b>
<a class="hl" name="90" href="#90">90</a>    <a href="/source/s?path=build/">build</a>/<a href="/source/s?path=build/tools/">tools</a>/<a href="/source/s?path=build/tools/compare_fileslist.py">compare_fileslist.py</a> <a href="/source/s?defs=$inputs&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">$inputs</a> &gt; <a href="/source/s?defs=$TEST_BUILD_DIR&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">$TEST_BUILD_DIR</a>/<a href="/source/s?path=sizes.html&amp;project=tools">sizes.html</a>
<a class="l" name="91" href="#91">91</a>}</span>
<a class="l" name="92" href="#92">92</a>
<a class="l" name="93" href="#93">93</a>