<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Function","xf",[["IsDifferent",20],["main",31]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class="c">#!/<a href="/source/s?path=/usr/">usr</a>/<a href="/source/s?path=/usr/bin/">bin</a>/<a href="/source/s?path=/usr/bin/env">env</a> python</span>
<a class="l" name="2" href="#2">2</a><span class="c">#</span>
<a class="l" name="3" href="#3">3</a><span class="c"># Copyright (C) 2009 The Android Open Source Project</span>
<a class="l" name="4" href="#4">4</a><span class="c">#</span>
<a class="l" name="5" href="#5">5</a><span class="c"># Licensed under the Apache License, Version 2.0 (the 'License');</span>
<a class="l" name="6" href="#6">6</a><span class="c"># you may not use this file except in compliance with the License.</span>
<a class="l" name="7" href="#7">7</a><span class="c"># You may obtain a copy of the License at</span>
<a class="l" name="8" href="#8">8</a><span class="c">#</span>
<a class="l" name="9" href="#9">9</a><span class="c">#      <a href="http://www.apache.org/licenses/LICENSE-2.0">http://www.apache.org/licenses/LICENSE-2.0</a></span>
<a class="hl" name="10" href="#10">10</a><span class="c">#</span>
<a class="l" name="11" href="#11">11</a><span class="c"># Unless required by applicable law or agreed to in writing, software</span>
<a class="l" name="12" href="#12">12</a><span class="c"># distributed under the License is distributed on an 'AS IS' BASIS,</span>
<a class="l" name="13" href="#13">13</a><span class="c"># WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.</span>
<a class="l" name="14" href="#14">14</a><span class="c"># See the License for the specific language governing permissions and</span>
<a class="l" name="15" href="#15">15</a><span class="c"># limitations under the License.</span>
<a class="l" name="16" href="#16">16</a><span class="c">#</span>
<a class="l" name="17" href="#17">17</a>
<a class="l" name="18" href="#18">18</a><b>import</b> <a href="/source/s?defs=cgi&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">cgi</a>, <a href="/source/s?defs=os&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">os</a>, <a href="/source/s?defs=string&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">string</a>, <a href="/source/s?defs=sys&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">sys</a>
<a class="l" name="19" href="#19">19</a>
<a class="hl" name="20" href="#20">20</a><b>def</b> <a class="xf" name="IsDifferent"/><a href="/source/s?refs=IsDifferent&amp;project=tools" class="xf intelliWindow-symbol" data-definition-place="def">IsDifferent</a>(<a href="/source/s?defs=row&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">row</a>):
<a class="l" name="21" href="#21">21</a>  <a href="/source/s?defs=val&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">val</a> = <b>None</b>
<a class="l" name="22" href="#22">22</a>  <b>for</b> v <b>in</b> <a href="/source/s?defs=row&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">row</a>:
<a class="l" name="23" href="#23">23</a>    <b>if</b> v:
<a class="l" name="24" href="#24">24</a>      <b>if</b> <b>not</b> <a href="/source/s?defs=val&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">val</a>:
<a class="l" name="25" href="#25">25</a>        <a href="/source/s?defs=val&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">val</a> = v
<a class="l" name="26" href="#26">26</a>      <b>else</b>:
<a class="l" name="27" href="#27">27</a>        <b>if</b> <a href="/source/s?defs=val&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">val</a> != v:
<a class="l" name="28" href="#28">28</a>          <b>return</b> <a href="/source/s?defs=True&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">True</a>
<a class="l" name="29" href="#29">29</a>  <b>return</b> <a href="/source/s?defs=False&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">False</a>
<a class="hl" name="30" href="#30">30</a>
<a class="l" name="31" href="#31">31</a><b>def</b> <a class="xf" name="main"/><a href="/source/s?refs=main&amp;project=tools" class="xf intelliWindow-symbol" data-definition-place="def">main</a>(<a href="/source/s?defs=argv&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">argv</a>):
<a class="l" name="32" href="#32">32</a>  <a href="/source/s?defs=inputs&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">inputs</a> = <a href="/source/s?defs=argv&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">argv</a>[<span class="n">1</span>:]
<a class="l" name="33" href="#33">33</a>  <a href="/source/s?defs=data&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">data</a> = {}
<a class="l" name="34" href="#34">34</a>  <a href="/source/s?defs=index&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">index</a> = <span class="n">0</span>
<a class="l" name="35" href="#35">35</a>  <b>for</b> <a href="/source/s?defs=input&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">input</a> <b>in</b> <a href="/source/s?defs=inputs&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">inputs</a>:
<a class="l" name="36" href="#36">36</a>    f = <a href="/source/s?defs=file&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">file</a>(<a href="/source/s?defs=input&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">input</a>, <span class="s">"r"</span>)
<a class="l" name="37" href="#37">37</a>    <a href="/source/s?defs=lines&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">lines</a> = f.<a href="/source/s?defs=readlines&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">readlines</a>()
<a class="l" name="38" href="#38">38</a>    f.<a href="/source/s?defs=close&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">close</a>()
<a class="l" name="39" href="#39">39</a>    <a href="/source/s?defs=lines&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">lines</a> = <a href="/source/s?defs=map&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">map</a>(<a href="/source/s?defs=string&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">string</a>.<a href="/source/s?defs=split&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">split</a>, <a href="/source/s?defs=lines&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">lines</a>)
<a class="hl" name="40" href="#40">40</a>    <a href="/source/s?defs=lines&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">lines</a> = <a href="/source/s?defs=map&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">map</a>(<b>lambda</b> (x,y): (y,<a href="/source/s?defs=int&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">int</a>(x)), <a href="/source/s?defs=lines&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">lines</a>)
<a class="l" name="41" href="#41">41</a>    <b>for</b> <a href="/source/s?defs=fn&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">fn</a>,<a href="/source/s?defs=sz&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">sz</a> <b>in</b> <a href="/source/s?defs=lines&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">lines</a>:
<a class="l" name="42" href="#42">42</a>      <b>if</b> <b>not</b> <a href="/source/s?defs=data&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">data</a>.<a href="/source/s?defs=has_key&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">has_key</a>(<a href="/source/s?defs=fn&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">fn</a>):
<a class="l" name="43" href="#43">43</a>        <a href="/source/s?defs=data&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">data</a>[<a href="/source/s?defs=fn&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">fn</a>] = {}
<a class="l" name="44" href="#44">44</a>      <a href="/source/s?defs=data&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">data</a>[<a href="/source/s?defs=fn&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">fn</a>][<a href="/source/s?defs=index&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">index</a>] = <a href="/source/s?defs=sz&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">sz</a>
<a class="l" name="45" href="#45">45</a>    <a href="/source/s?defs=index&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">index</a> = <a href="/source/s?defs=index&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">index</a> + <span class="n">1</span>
<a class="l" name="46" href="#46">46</a>  <a href="/source/s?defs=rows&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">rows</a> = []
<a class="l" name="47" href="#47">47</a>  <b>for</b> <a href="/source/s?defs=fn&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">fn</a>,<a href="/source/s?defs=sizes&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">sizes</a> <b>in</b> <a href="/source/s?defs=data&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">data</a>.<a href="/source/s?defs=iteritems&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">iteritems</a>():
<a class="l" name="48" href="#48">48</a>    <a href="/source/s?defs=row&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">row</a> = [<a href="/source/s?defs=fn&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">fn</a>]
<a class="l" name="49" href="#49">49</a>    <b>for</b> i <b>in</b> <a href="/source/s?defs=range&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">range</a>(<span class="n">0</span>,<a href="/source/s?defs=index&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">index</a>):
<a class="hl" name="50" href="#50">50</a>      <b>if</b> <a href="/source/s?defs=sizes&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">sizes</a>.<a href="/source/s?defs=has_key&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">has_key</a>(i):
<a class="l" name="51" href="#51">51</a>        <a href="/source/s?defs=row&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">row</a>.<a href="/source/s?defs=append&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">append</a>(<a href="/source/s?defs=sizes&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">sizes</a>[i])
<a class="l" name="52" href="#52">52</a>      <b>else</b>:
<a class="l" name="53" href="#53">53</a>        <a href="/source/s?defs=row&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">row</a>.<a href="/source/s?defs=append&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">append</a>(<b>None</b>)
<a class="l" name="54" href="#54">54</a>    <a href="/source/s?defs=rows&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">rows</a>.<a href="/source/s?defs=append&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">append</a>(<a href="/source/s?defs=row&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">row</a>)
<a class="l" name="55" href="#55">55</a>  <a href="/source/s?defs=rows&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">rows</a> = <a href="/source/s?defs=sorted&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">sorted</a>(<a href="/source/s?defs=rows&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">rows</a>, <a href="/source/s?defs=key&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">key</a>=<b>lambda</b> x: x[<span class="n">0</span>])
<a class="l" name="56" href="#56">56</a>  <b>print</b> <span class="s">"""&lt;html&gt;
<a class="l" name="57" href="#57">57</a>    &lt;head&gt;
<a class="l" name="58" href="#58">58</a>      &lt;style type="<a href="/source/s?path=text/">text</a>/<a href="/source/s?path=text/css">css</a>"&gt;
<a class="l" name="59" href="#59">59</a>        .fn, .sz, .z, .d {
<a class="hl" name="60" href="#60">60</a>          padding-left: 10px;
<a class="l" name="61" href="#61">61</a>          padding-right: 10px;
<a class="l" name="62" href="#62">62</a>        }
<a class="l" name="63" href="#63">63</a>        .sz, .z, .d {
<a class="l" name="64" href="#64">64</a>          text-align: right;
<a class="l" name="65" href="#65">65</a>        }
<a class="l" name="66" href="#66">66</a>        .fn {
<a class="l" name="67" href="#67">67</a>          background-color: #ffffdd;
<a class="l" name="68" href="#68">68</a>        }
<a class="l" name="69" href="#69">69</a>        .sz {
<a class="hl" name="70" href="#70">70</a>          background-color: #ffffcc;
<a class="l" name="71" href="#71">71</a>        }
<a class="l" name="72" href="#72">72</a>        .z {
<a class="l" name="73" href="#73">73</a>          background-color: #ffcccc;
<a class="l" name="74" href="#74">74</a>        }
<a class="l" name="75" href="#75">75</a>        .d {
<a class="l" name="76" href="#76">76</a>          background-color: #99ccff;
<a class="l" name="77" href="#77">77</a>        }
<a class="l" name="78" href="#78">78</a>      &lt;/style&gt;
<a class="l" name="79" href="#79">79</a>    &lt;/head&gt;
<a class="hl" name="80" href="#80">80</a>    &lt;body&gt;
<a class="l" name="81" href="#81">81</a>  """</span>
<a class="l" name="82" href="#82">82</a>  <b>print</b> <span class="s">"&lt;table&gt;"</span>
<a class="l" name="83" href="#83">83</a>  <b>print</b> <span class="s">"&lt;tr&gt;"</span>
<a class="l" name="84" href="#84">84</a>  <b>for</b> <a href="/source/s?defs=input&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">input</a> <b>in</b> <a href="/source/s?defs=inputs&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">inputs</a>:
<a class="l" name="85" href="#85">85</a>    <a href="/source/s?defs=combo&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">combo</a> = <a href="/source/s?defs=input&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">input</a>.<a href="/source/s?defs=split&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">split</a>(<a href="/source/s?defs=os&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">os</a>.<a href="/source/s?defs=path&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">path</a>.<a href="/source/s?defs=sep&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">sep</a>)[<span class="n">1</span>]
<a class="l" name="86" href="#86">86</a>    <b>print</b> <span class="s">"  &lt;td class='fn'&gt;%s&lt;/td&gt;"</span> % <a href="/source/s?defs=cgi&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">cgi</a>.<a href="/source/s?defs=escape&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">escape</a>(<a href="/source/s?defs=combo&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">combo</a>)
<a class="l" name="87" href="#87">87</a>  <b>print</b> <span class="s">"&lt;/tr&gt;"</span>
<a class="l" name="88" href="#88">88</a>
<a class="l" name="89" href="#89">89</a>  <b>for</b> <a href="/source/s?defs=row&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">row</a> <b>in</b> <a href="/source/s?defs=rows&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">rows</a>:
<a class="hl" name="90" href="#90">90</a>    <b>print</b> <span class="s">"&lt;tr&gt;"</span>
<a class="l" name="91" href="#91">91</a>    <b>for</b> <a href="/source/s?defs=sz&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">sz</a> <b>in</b> <a href="/source/s?defs=row&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">row</a>[<span class="n">1</span>:]:
<a class="l" name="92" href="#92">92</a>      <b>if</b> <b>not</b> <a href="/source/s?defs=sz&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">sz</a>:
<a class="l" name="93" href="#93">93</a>        <b>print</b> <span class="s">"  &lt;td class='z'&gt;&amp;nbsp;&lt;/td&gt;"</span>
<a class="l" name="94" href="#94">94</a>      <b>elif</b> <a class="d intelliWindow-symbol" href="#IsDifferent" data-definition-place="defined-in-file">IsDifferent</a>(<a href="/source/s?defs=row&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">row</a>[<span class="n">1</span>:]):
<a class="l" name="95" href="#95">95</a>        <b>print</b> <span class="s">"  &lt;td class='d'&gt;%d&lt;/td&gt;"</span> % <a href="/source/s?defs=sz&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">sz</a>
<a class="l" name="96" href="#96">96</a>      <b>else</b>:
<a class="l" name="97" href="#97">97</a>        <b>print</b> <span class="s">"  &lt;td class='sz'&gt;%d&lt;/td&gt;"</span> % <a href="/source/s?defs=sz&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">sz</a>
<a class="l" name="98" href="#98">98</a>    <b>print</b> <span class="s">"  &lt;td class='fn'&gt;%s&lt;/td&gt;"</span> % <a href="/source/s?defs=cgi&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">cgi</a>.<a href="/source/s?defs=escape&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">escape</a>(<a href="/source/s?defs=row&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">row</a>[<span class="n">0</span>])
<a class="l" name="99" href="#99">99</a>    <b>print</b> <span class="s">"&lt;/tr&gt;"</span>
<a class="hl" name="100" href="#100">100</a>  <b>print</b> <span class="s">"&lt;/table&gt;"</span>
<a class="l" name="101" href="#101">101</a>  <b>print</b> <span class="s">"&lt;/body&gt;&lt;/html&gt;"</span>
<a class="l" name="102" href="#102">102</a>
<a class="l" name="103" href="#103">103</a><b>if</b> <a href="/source/s?defs=__name__&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">__name__</a> == <span class="s">'__main__'</span>:
<a class="l" name="104" href="#104">104</a>  <a class="d intelliWindow-symbol" href="#main" data-definition-place="defined-in-file">main</a>(<a href="/source/s?defs=sys&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">sys</a>.<a href="/source/s?defs=argv&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">argv</a>)
<a class="l" name="105" href="#105">105</a>
<a class="l" name="106" href="#106">106</a>
<a class="l" name="107" href="#107">107</a>