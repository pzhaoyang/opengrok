<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class="c">// Simple JavaScript Templating</span>
<a class="l" name="2" href="#2">2</a><span class="c">// John Resig - <a href="http://ejohn.org/">http://ejohn.org/</a> - MIT Licensed</span>
<a class="l" name="3" href="#3">3</a>(<b>function</b>(){
<a class="l" name="4" href="#4">4</a>  <b>var</b> <a href="/source/s?defs=cache&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">cache</a> = {};
<a class="l" name="5" href="#5">5</a>
<a class="l" name="6" href="#6">6</a>  <b>this</b>.<a href="/source/s?defs=tmpl&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">tmpl</a> = <b>function</b> <a href="/source/s?defs=tmpl&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">tmpl</a>(<a href="/source/s?defs=str&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">str</a>, <a href="/source/s?defs=data&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">data</a>){
<a class="l" name="7" href="#7">7</a>    <span class="c">// Figure out if we're getting a template, or if we need to</span>
<a class="l" name="8" href="#8">8</a>    <span class="c">// load the template - and be sure to cache the result.</span>
<a class="l" name="9" href="#9">9</a>    <b>var</b> <a href="/source/s?defs=fn&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">fn</a> = !/\W/.<a href="/source/s?defs=test&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">test</a>(<a href="/source/s?defs=str&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">str</a>) ?
<a class="hl" name="10" href="#10">10</a>      <a href="/source/s?defs=cache&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">cache</a>[<a href="/source/s?defs=str&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">str</a>] = <a href="/source/s?defs=cache&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">cache</a>[<a href="/source/s?defs=str&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">str</a>] ||
<a class="l" name="11" href="#11">11</a>        <a href="/source/s?defs=tmpl&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">tmpl</a>(<a href="/source/s?defs=document&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">document</a>.<a href="/source/s?defs=getElementById&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">getElementById</a>(<a href="/source/s?defs=str&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">str</a>).<a href="/source/s?defs=innerHTML&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">innerHTML</a>) :
<a class="l" name="12" href="#12">12</a>
<a class="l" name="13" href="#13">13</a>      <span class="c">// Generate a reusable function that will serve as a template</span>
<a class="l" name="14" href="#14">14</a>      <span class="c">// generator (and which will be cached).</span>
<a class="l" name="15" href="#15">15</a>      <b>new</b> <b>Function</b>(<span class="s">"obj"</span>,
<a class="l" name="16" href="#16">16</a>        <span class="s">"var p=[],print=function(){p.push.apply(p,arguments);};"</span> +
<a class="l" name="17" href="#17">17</a>
<a class="l" name="18" href="#18">18</a>        <span class="c">// Introduce the data as local variables using with(){}</span>
<a class="l" name="19" href="#19">19</a>        <span class="s">"with(obj){p.push('"</span> +
<a class="hl" name="20" href="#20">20</a>
<a class="l" name="21" href="#21">21</a>        <span class="c">// Convert the template into pure JavaScript</span>
<a class="l" name="22" href="#22">22</a>        <a href="/source/s?defs=str&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">str</a>
<a class="l" name="23" href="#23">23</a>          .<a href="/source/s?defs=replace&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">replace</a>(/[\r\t\n]/g, <span class="s">" "</span>)
<a class="l" name="24" href="#24">24</a>          .<a href="/source/s?defs=split&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">split</a>(<span class="s">"&lt;%"</span>).<a href="/source/s?defs=join&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">join</a>(<span class="s">"\t"</span>)
<a class="l" name="25" href="#25">25</a>          .<a href="/source/s?defs=replace&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">replace</a>(/((^|%&gt;)[^\t]*)<span class="s">'/g, "$1\r")
<a class="l" name="26" href="#26">26</a>          .replace(/\t=(.*?)%&gt;/g, "'</span>,<a href="/source/s?defs=$1&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">$1</a>,<span class="s">'")
<a class="l" name="27" href="#27">27</a>          .split("\t").join("'</span>);<span class="s">")
<a class="l" name="28" href="#28">28</a>          .split("</span>%&gt;<span class="s">").join("</span>p.<a href="/source/s?defs=push&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">push</a>(<span class="s">'")
<a class="l" name="29" href="#29">29</a>          .split("\r").join("\\'</span><span class="s">")
<a class="hl" name="30" href="#30">30</a>      + "</span><span class="s">');}return p.join('</span><span class="s">');");
<a class="l" name="31" href="#31">31</a>
<a class="l" name="32" href="#32">32</a>    // Provide some basic currying to the user
<a class="l" name="33" href="#33">33</a>    return data ? fn( data ) : fn;
<a class="l" name="34" href="#34">34</a>  };
<a class="l" name="35" href="#35">35</a>})();