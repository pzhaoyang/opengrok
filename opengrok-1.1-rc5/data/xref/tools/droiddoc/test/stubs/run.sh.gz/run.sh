<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class="c">#!/<a href="/source/s?path=/bin/">bin</a>/<a href="/source/s?path=/bin/sh">sh</a></span>
<a class="l" name="2" href="#2">2</a><span class="c">#</span>
<a class="l" name="3" href="#3">3</a><span class="c"># Copyright (C) 2008 The Android Open Source Project</span>
<a class="l" name="4" href="#4">4</a><span class="c">#</span>
<a class="l" name="5" href="#5">5</a><span class="c"># Licensed under the Apache License, Version 2.0 (the "License");</span>
<a class="l" name="6" href="#6">6</a><span class="c"># you may not use this file except in compliance with the License.</span>
<a class="l" name="7" href="#7">7</a><span class="c"># You may obtain a copy of the License at</span>
<a class="l" name="8" href="#8">8</a><span class="c">#</span>
<a class="l" name="9" href="#9">9</a><span class="c">#      <a href="http://www.apache.org/licenses/LICENSE-2.0">http://www.apache.org/licenses/LICENSE-2.0</a></span>
<a class="hl" name="10" href="#10">10</a><span class="c">#</span>
<a class="l" name="11" href="#11">11</a><span class="c"># Unless required by applicable law or agreed to in writing, software</span>
<a class="l" name="12" href="#12">12</a><span class="c"># distributed under the License is distributed on an "AS IS" BASIS,</span>
<a class="l" name="13" href="#13">13</a><span class="c"># WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.</span>
<a class="l" name="14" href="#14">14</a><span class="c"># See the License for the specific language governing permissions and</span>
<a class="l" name="15" href="#15">15</a><span class="c"># limitations under the License.</span>
<a class="l" name="16" href="#16">16</a>
<a class="l" name="17" href="#17">17</a><a href="/source/s?defs=DIR&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">DIR</a>=<a href="/source/s?path=build/">build</a>/<a href="/source/s?path=build/tools/">tools</a>/<a href="/source/s?path=build/tools/droiddoc/">droiddoc</a>/<a href="/source/s?path=build/tools/droiddoc/test/">test</a>/<a href="/source/s?path=build/tools/droiddoc/test/stubs">stubs</a>
<a class="l" name="18" href="#18">18</a>
<a class="l" name="19" href="#19">19</a><b>pushd</b> <a href="/source/s?defs=$TOP&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">$TOP</a>
<a class="hl" name="20" href="#20">20</a>
<a class="l" name="21" href="#21">21</a>. <a href="/source/s?defs=$TOP&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">$TOP</a>/<a href="/source/s?defs=$DIR&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">$DIR</a>/<a href="/source/s?path=func.sh&amp;project=tools">func.sh</a>
<a class="l" name="22" href="#22">22</a>
<a class="l" name="23" href="#23">23</a><a href="/source/s?defs=mkdir&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">mkdir</a> -p <a href="/source/s?path=out/">out</a>/<a href="/source/s?path=out/stubs_compiled">stubs_compiled</a>
<a class="l" name="24" href="#24">24</a><a href="/source/s?defs=find&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">find</a> <a href="/source/s?defs=$DIR&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">$DIR</a>/<a href="/source/s?defs=src&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">src</a> -<a href="/source/s?defs=name&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">name</a> <span class="s">"*.java"</span> | <a href="/source/s?defs=xargs&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">xargs</a> <a href="/source/s?defs=javac&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">javac</a> -d <a href="/source/s?path=out/">out</a>/<a href="/source/s?path=out/stubs_compiled">stubs_compiled</a>
<a class="l" name="25" href="#25">25</a>
<a class="l" name="26" href="#26">26</a><a href="/source/s?defs=build_stubs&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">build_stubs</a> a <a href="/source/s?defs=$DIR&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">$DIR</a>/<a href="/source/s?defs=src&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">src</a> <a href="/source/s?defs=$A_STUBS&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">$A_STUBS</a>
<a class="l" name="27" href="#27">27</a><a href="/source/s?defs=build_stubs&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">build_stubs</a> b <a href="/source/s?defs=$A_STUBS&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">$A_STUBS</a> <a href="/source/s?defs=$B_STUBS&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">$B_STUBS</a>
<a class="l" name="28" href="#28">28</a>
<a class="l" name="29" href="#29">29</a><a href="/source/s?defs=compile_stubs&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">compile_stubs</a> a <a href="/source/s?defs=$A_STUBS&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">$A_STUBS</a>
<a class="hl" name="30" href="#30">30</a>
<a class="l" name="31" href="#31">31</a><b>echo</b> <a href="/source/s?defs=EXPECTED&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">EXPECTED</a>
<a class="l" name="32" href="#32">32</a><a href="/source/s?defs=diff&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">diff</a> -r <a href="/source/s?defs=$DIR&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">$DIR</a>/<a href="/source/s?defs=expected&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">expected</a> <a href="/source/s?defs=$A_STUBS&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">$A_STUBS</a>
<a class="l" name="33" href="#33">33</a><b>echo</b> <a href="/source/s?defs=TWICE&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">TWICE</a> <a href="/source/s?defs=STUBBED&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">STUBBED</a>
<a class="l" name="34" href="#34">34</a><a href="/source/s?defs=diff&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">diff</a> -r <a href="/source/s?defs=$A_STUBS&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">$A_STUBS</a> <a href="/source/s?defs=$B_STUBS&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">$B_STUBS</a>
<a class="l" name="35" href="#35">35</a>
<a class="l" name="36" href="#36">36</a><b>popd</b> &amp;&gt; /<a href="/source/s?path=/dev/">dev</a>/<a href="/source/s?path=/dev/null">null</a>
<a class="l" name="37" href="#37">37</a>
<a class="l" name="38" href="#38">38</a>
<a class="l" name="39" href="#39">39</a>
<a class="hl" name="40" href="#40">40</a>