<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Package","xp",[["com.android.stubs",1]]],["Enum","xe",[["A",4],["B",5],["C",6],["SomeEnum",2]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class='fold-space'>&nbsp;</span><b>package</b> <a href="/source/s?defs=com&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">com</a>.<a href="/source/s?defs=android&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">android</a>.<a href="/source/s?defs=stubs&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">stubs</a>&#59;
<a class="l" name="2" href="#2">2</a><span class='fold-space'>&nbsp;</span><b>public</b> <b>enum</b> <a class="xe" name="SomeEnum"/><a href="/source/s?refs=SomeEnum&amp;project=tools" class="xe intelliWindow-symbol" data-definition-place="def">SomeEnum</a>
<a class="l" name="3" href="#3">3</a><span class='fold-space'>&nbsp;</span>&#123;
<a class="l" name="4" href="#4">4</a><span class='fold-space'>&nbsp;</span>A(),
<a class="l" name="5" href="#5">5</a><span class='fold-space'>&nbsp;</span>B(),
<a class="l" name="6" href="#6">6</a><span class='fold-space'>&nbsp;</span>C()&#59;
<a class="l" name="7" href="#7">7</a><span class='fold-space'>&nbsp;</span>&#125;
<a class="l" name="8" href="#8">8</a><span class='fold-space'>&nbsp;</span>