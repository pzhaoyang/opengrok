<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["AbsListView",19]]],["Package","xp",[["com.android.generics",17]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class='fold-space'>&nbsp;</span><span class="c">/*
<a class="l" name="2" href="#2">2</a><span class='fold-space'>&nbsp;</span> * Copyright (C) 2008 The Android Open Source Project
<a class="l" name="3" href="#3">3</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="4" href="#4">4</a><span class='fold-space'>&nbsp;</span> * Licensed under the Apache License, Version 2.0 (the "License");
<a class="l" name="5" href="#5">5</a><span class='fold-space'>&nbsp;</span> * you may not use this file except in compliance with the License.
<a class="l" name="6" href="#6">6</a><span class='fold-space'>&nbsp;</span> * You may obtain a copy of the License at
<a class="l" name="7" href="#7">7</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="8" href="#8">8</a><span class='fold-space'>&nbsp;</span> *      <a href="http://www.apache.org/licenses/LICENSE-2.0">http://www.apache.org/licenses/LICENSE-2.0</a>
<a class="l" name="9" href="#9">9</a><span class='fold-space'>&nbsp;</span> *
<a class="hl" name="10" href="#10">10</a><span class='fold-space'>&nbsp;</span> * Unless required by applicable law or agreed to in writing, software
<a class="l" name="11" href="#11">11</a><span class='fold-space'>&nbsp;</span> * distributed under the License is distributed on an "AS IS" BASIS,
<a class="l" name="12" href="#12">12</a><span class='fold-space'>&nbsp;</span> * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
<a class="l" name="13" href="#13">13</a><span class='fold-space'>&nbsp;</span> * See the License for the specific language governing permissions and
<a class="l" name="14" href="#14">14</a><span class='fold-space'>&nbsp;</span> * limitations under the License.
<a class="l" name="15" href="#15">15</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="16" href="#16">16</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="17" href="#17">17</a><span class='fold-space'>&nbsp;</span><b>package</b> <a href="/source/s?defs=com&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">com</a>.<a href="/source/s?defs=android&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">android</a>.<a href="/source/s?defs=generics&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">generics</a>&#59;
<a class="l" name="18" href="#18">18</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="19" href="#19">19</a><span class='fold-space'>&nbsp;</span><b>public</b> <b>class</b> <a class="xc" name="AbsListView"/><a href="/source/s?refs=AbsListView&amp;project=tools" class="xc intelliWindow-symbol" data-definition-place="def">AbsListView</a> <b>implements</b> <a href="/source/s?defs=AdapterView&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">AdapterView</a>&lt;<a href="/source/s?defs=ListAdapter&amp;project=tools" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ListAdapter</a>&gt; &#123;
<a class="hl" name="20" href="#20">20</a><span class='fold-space'>&nbsp;</span>&#125;
<a class="l" name="21" href="#21">21</a><span class='fold-space'>&nbsp;</span>