<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [];} /* ]]> */</script><a class="l" name="1" href="#1">1</a>zipalign -- zip archive alignment tool
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a>usage: zipalign [-f] [-v] &lt;align&gt; <a href="/source/s?path=infile.zip&amp;project=tools">infile.zip</a> <a href="/source/s?path=outfile.zip&amp;project=tools">outfile.zip</a>
<a class="l" name="4" href="#4">4</a>       zipalign -c [-v] &lt;align&gt; <a href="/source/s?path=infile.zip&amp;project=tools">infile.zip</a>
<a class="l" name="5" href="#5">5</a>
<a class="l" name="6" href="#6">6</a>  -c : check alignment only (does not modify file)
<a class="l" name="7" href="#7">7</a>  -f : overwrite existing <a href="/source/s?path=outfile.zip&amp;project=tools">outfile.zip</a>
<a class="l" name="8" href="#8">8</a>  -p : page align stored shared object files
<a class="l" name="9" href="#9">9</a>  -v : verbose output
<a class="hl" name="10" href="#10">10</a>  &lt;align&gt; is in bytes, <a href="/source/s?path=e.g.&amp;project=tools">e.g.</a> "4" provides 32-bit alignment
<a class="l" name="11" href="#11">11</a>  <a href="/source/s?path=infile.zip&amp;project=tools">infile.zip</a> is an existing Zip archive
<a class="l" name="12" href="#12">12</a>  <a href="/source/s?path=outfile.zip&amp;project=tools">outfile.zip</a> will be created
<a class="l" name="13" href="#13">13</a>
<a class="l" name="14" href="#14">14</a>
<a class="l" name="15" href="#15">15</a>The purpose of zipalign is to ensure that all uncompressed data starts
<a class="l" name="16" href="#16">16</a>with a particular alignment relative to the start of the file.  This
<a class="l" name="17" href="#17">17</a>allows those portions to be accessed directly with mmap() even if they
<a class="l" name="18" href="#18">18</a>contain binary data with alignment restrictions.
<a class="l" name="19" href="#19">19</a>
<a class="hl" name="20" href="#20">20</a>Some data needs to be word-aligned for easy access, others might benefit
<a class="l" name="21" href="#21">21</a>from being page-aligned.  The adjustment is made by altering the size of
<a class="l" name="22" href="#22">22</a>the "extra" field in the zip Local File Header sections.  Existing data
<a class="l" name="23" href="#23">23</a>in the "extra" fields may be altered by this process.
<a class="l" name="24" href="#24">24</a>
<a class="l" name="25" href="#25">25</a>Compressed data isn't very useful until it's uncompressed, so there's no
<a class="l" name="26" href="#26">26</a>need to adjust its alignment.
<a class="l" name="27" href="#27">27</a>
<a class="l" name="28" href="#28">28</a>Alterations to the archive, such as renaming or deleting entries, will
<a class="l" name="29" href="#29">29</a>potentially disrupt the alignment of the modified entry and all later
<a class="hl" name="30" href="#30">30</a>entries.  Files added to an "aligned" archive will not be aligned.
<a class="l" name="31" href="#31">31</a>
<a class="l" name="32" href="#32">32</a>By default, zipalign will not overwrite an existing output file.  With the
<a class="l" name="33" href="#33">33</a>"-f" flag, an existing file will be overwritten.
<a class="l" name="34" href="#34">34</a>
<a class="l" name="35" href="#35">35</a>You can use the "-c" flag to test whether a zip archive is properly aligned.
<a class="l" name="36" href="#36">36</a>
<a class="l" name="37" href="#37">37</a>The "-p" flag aligns any file with a ".so" extension, and which is stored
<a class="l" name="38" href="#38">38</a>uncompressed in the zip archive, to a 4096-byte page boundary.  This
<a class="l" name="39" href="#39">39</a>facilitates directly loading shared libraries from inside a zip archive.
<a class="hl" name="40" href="#40">40</a>
<a class="l" name="41" href="#41">41</a>