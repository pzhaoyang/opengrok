<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><a href="/source/s?defs=NM&amp;project=core" class="intelliWindow-symbol" data-definition-place="undefined-in-file">NM</a>=$<span class="n">1</span>
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><b>shift</b>
<a class="l" name="4" href="#4">4</a>
<a class="l" name="5" href="#5">5</a><a href="/source/s?defs=PREFIX&amp;project=core" class="intelliWindow-symbol" data-definition-place="undefined-in-file">PREFIX</a>=$<span class="n">1</span>
<a class="l" name="6" href="#6">6</a>
<a class="l" name="7" href="#7">7</a><b>shift</b>
<a class="l" name="8" href="#8">8</a>
<a class="l" name="9" href="#9">9</a><a href="/source/s?defs=SUFFIX&amp;project=core" class="intelliWindow-symbol" data-definition-place="undefined-in-file">SUFFIX</a>=$<span class="n">1</span>
<a class="hl" name="10" href="#10">10</a>
<a class="l" name="11" href="#11">11</a><b>shift</b>
<a class="l" name="12" href="#12">12</a>
<a class="l" name="13" href="#13">13</a><b>while</b> <b>test</b> <span class="s">"$1"</span> != <span class="s">""</span>
<a class="l" name="14" href="#14">14</a><b>do</b>
<a class="l" name="15" href="#15">15</a>    <a href="/source/s?defs=$NM&amp;project=core" class="intelliWindow-symbol" data-definition-place="undefined-in-file">$NM</a> -g -<a href="/source/s?defs=fp&amp;project=core" class="intelliWindow-symbol" data-definition-place="undefined-in-file">fp</a> $<span class="n">1</span> | <b>while</b> <b>read</b> -a <a href="/source/s?defs=line&amp;project=core" class="intelliWindow-symbol" data-definition-place="undefined-in-file">line</a>
<a class="l" name="16" href="#16">16</a>    <b>do</b>
<a class="l" name="17" href="#17">17</a>	<b>type</b>=${<a href="/source/s?defs=line&amp;project=core" class="intelliWindow-symbol" data-definition-place="undefined-in-file">line</a>[<span class="n">1</span>]}
<a class="l" name="18" href="#18">18</a>	<span class="c"># if [[ "$type" != "V" &amp;&amp; "$type" != "U" ]]; then</span>
<a class="l" name="19" href="#19">19</a>	<span class="c">#if [[ "$type" != "W" &amp;&amp; "$type" != "V" &amp;&amp; "$type" != "U" ]]; then</span>
<a class="hl" name="20" href="#20">20</a>	    <b>echo</b> <span class="s">"<a href="/source/s?refs=$PREFIX&amp;project=core">$PREFIX</a>${line[0]}<a href="/source/s?refs=$SUFFIX&amp;project=core">$SUFFIX</a> # ${line[1]}"</span>
<a class="l" name="21" href="#21">21</a>	<span class="c">#fi</span>
<a class="l" name="22" href="#22">22</a>    <b>done</b>
<a class="l" name="23" href="#23">23</a>
<a class="l" name="24" href="#24">24</a>    <b>shift</b>
<a class="l" name="25" href="#25">25</a><b>done</b>
<a class="l" name="26" href="#26">26</a>