<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class="c">#!/<a href="/source/s?path=/bin/">bin</a>/<a href="/source/s?path=/bin/sh">sh</a></span>
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c"># When using a process wrapper, this is the top-level</span>
<a class="l" name="4" href="#4">4</a><span class="c"># command that is executed instead of the server</span>
<a class="l" name="5" href="#5">5</a><span class="c"># command.  It starts a new xterm in which the user can</span>
<a class="l" name="6" href="#6">6</a><span class="c"># interact with the new process.</span>
<a class="l" name="7" href="#7">7</a><span class="c">#</span>
<a class="l" name="8" href="#8">8</a><span class="c"># Inside of the xterm is a gdb session, through which</span>
<a class="l" name="9" href="#9">9</a><span class="c"># the user can debug the new process.</span>
<a class="hl" name="10" href="#10">10</a>
<a class="l" name="11" href="#11">11</a><span class="c"># Save away these variables, since we may loose them</span>
<a class="l" name="12" href="#12">12</a><span class="c"># when starting in the xterm.</span>
<a class="l" name="13" href="#13">13</a><b>export</b> <a href="/source/s?defs=PREV_LD_LIBRARY_PATH&amp;project=core" class="intelliWindow-symbol" data-definition-place="undefined-in-file">PREV_LD_LIBRARY_PATH</a>=<a href="/source/s?defs=$LD_LIBRARY_PATH&amp;project=core" class="intelliWindow-symbol" data-definition-place="undefined-in-file">$LD_LIBRARY_PATH</a>
<a class="l" name="14" href="#14">14</a><b>export</b> <a href="/source/s?defs=PREV_PATH&amp;project=core" class="intelliWindow-symbol" data-definition-place="undefined-in-file">PREV_PATH</a>=<a href="/source/s?defs=$PATH&amp;project=core" class="intelliWindow-symbol" data-definition-place="undefined-in-file">$PATH</a>
<a class="l" name="15" href="#15">15</a>
<a class="l" name="16" href="#16">16</a><a href="/source/s?defs=gnome&amp;project=core" class="intelliWindow-symbol" data-definition-place="undefined-in-file">gnome</a>-<a href="/source/s?defs=terminal&amp;project=core" class="intelliWindow-symbol" data-definition-place="undefined-in-file">terminal</a> -t <span class="s">"Wrapper: $1"</span> --<a href="/source/s?defs=disable&amp;project=core" class="intelliWindow-symbol" data-definition-place="undefined-in-file">disable</a>-<a href="/source/s?defs=factory&amp;project=core" class="intelliWindow-symbol" data-definition-place="undefined-in-file">factory</a> -x $<span class="n">2</span>/<a href="/source/s?path=process_wrapper_gdb.sh&amp;project=core">process_wrapper_gdb.sh</a> <span class="s">"$@"</span>
<a class="l" name="17" href="#17">17</a>
<a class="l" name="18" href="#18">18</a>