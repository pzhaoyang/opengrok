<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Macro","xm",[["HAVE_MS_C_RUNTIME",68],["HAVE_WIN32_IPC",59],["HAVE_WINDOWS_PATHS",90],["HAVE_WINSOCK",73],["OS_PATH_SEPARATOR",95],["S_IRGRP",101],["WIN32",86],["_ANDROID_CONFIG_H",26],["_FILE_OFFSET_BITS",80],["_LARGEFILE_SOURCE",81],["_WIN32",87],["_WIN32_WINNT",88],["__BEGIN_DECLS",44],["__BEGIN_DECLS",46],["__END_DECLS",52],["__END_DECLS",54]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class='fold-space'>&nbsp;</span><span class="c">/*
<a class="l" name="2" href="#2">2</a><span class='fold-space'>&nbsp;</span> * Copyright (C) 2005 The Android Open Source Project
<a class="l" name="3" href="#3">3</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="4" href="#4">4</a><span class='fold-space'>&nbsp;</span> * Licensed under the Apache License, Version 2.0 (the "License");
<a class="l" name="5" href="#5">5</a><span class='fold-space'>&nbsp;</span> * you may not use this file except in compliance with the License.
<a class="l" name="6" href="#6">6</a><span class='fold-space'>&nbsp;</span> * You may obtain a copy of the License at
<a class="l" name="7" href="#7">7</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="8" href="#8">8</a><span class='fold-space'>&nbsp;</span> *      <a href="http://www.apache.org/licenses/LICENSE-2.0">http://www.apache.org/licenses/LICENSE-2.0</a>
<a class="l" name="9" href="#9">9</a><span class='fold-space'>&nbsp;</span> *
<a class="hl" name="10" href="#10">10</a><span class='fold-space'>&nbsp;</span> * Unless required by applicable law or agreed to in writing, software
<a class="l" name="11" href="#11">11</a><span class='fold-space'>&nbsp;</span> * distributed under the License is distributed on an "AS IS" BASIS,
<a class="l" name="12" href="#12">12</a><span class='fold-space'>&nbsp;</span> * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
<a class="l" name="13" href="#13">13</a><span class='fold-space'>&nbsp;</span> * See the License for the specific language governing permissions and
<a class="l" name="14" href="#14">14</a><span class='fold-space'>&nbsp;</span> * limitations under the License.
<a class="l" name="15" href="#15">15</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="16" href="#16">16</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="17" href="#17">17</a><span class='fold-space'>&nbsp;</span><span class="c">/*
<a class="l" name="18" href="#18">18</a><span class='fold-space'>&nbsp;</span> * Android config -- "CYGWIN_NT-5.1".
<a class="l" name="19" href="#19">19</a><span class='fold-space'>&nbsp;</span> *
<a class="hl" name="20" href="#20">20</a><span class='fold-space'>&nbsp;</span> * Cygwin has pthreads, but GDB seems to get confused if you use it to
<a class="l" name="21" href="#21">21</a><span class='fold-space'>&nbsp;</span> * create threads.  By "confused", I mean it freezes up the first time the
<a class="l" name="22" href="#22">22</a><span class='fold-space'>&nbsp;</span> * debugged process creates a thread, even if you use CreateThread.  The
<a class="l" name="23" href="#23">23</a><span class='fold-space'>&nbsp;</span> * mere presence of pthreads linkage seems to cause problems.
<a class="l" name="24" href="#24">24</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="25" href="#25">25</a><span class='fold-space'>&nbsp;</span>#<b>ifndef</b> <a class="d intelliWindow-symbol" href="#_ANDROID_CONFIG_H" data-definition-place="defined-in-file">_ANDROID_CONFIG_H</a>
<a class="l" name="26" href="#26">26</a><span class='fold-space'>&nbsp;</span>#<b>define</b> <a href="/source/s?refs=_ANDROID_CONFIG_H&amp;project=core" class="xm intelliWindow-symbol" data-definition-place="def">_ANDROID_CONFIG_H</a>
<a class="l" name="27" href="#27">27</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="28" href="#28">28</a><span class='fold-space'>&nbsp;</span><span class="c">/*
<a class="l" name="29" href="#29">29</a><span class='fold-space'>&nbsp;</span> * ===========================================================================
<a class="hl" name="30" href="#30">30</a><span class='fold-space'>&nbsp;</span> *                              !!! IMPORTANT !!!
<a class="l" name="31" href="#31">31</a><span class='fold-space'>&nbsp;</span> * ===========================================================================
<a class="l" name="32" href="#32">32</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="33" href="#33">33</a><span class='fold-space'>&nbsp;</span> * This file is included by ALL C/C++ source files.  Don't put anything in
<a class="l" name="34" href="#34">34</a><span class='fold-space'>&nbsp;</span> * here unless you are absolutely certain it can't go anywhere else.
<a class="l" name="35" href="#35">35</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="36" href="#36">36</a><span class='fold-space'>&nbsp;</span> * Any C++ stuff must be wrapped with "#ifdef __cplusplus".  Do not use "//"
<a class="l" name="37" href="#37">37</a><span class='fold-space'>&nbsp;</span> * comments.
<a class="l" name="38" href="#38">38</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="39" href="#39">39</a><span class='fold-space'>&nbsp;</span>
<a class="hl" name="40" href="#40">40</a><span class='fold-space'>&nbsp;</span><span class="c">/* MingW doesn't define __BEGIN_DECLS / __END_DECLS. */</span>
<a class="l" name="41" href="#41">41</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="42" href="#42">42</a><span class='fold-space'>&nbsp;</span>#<b>ifndef</b> <a href="/source/s?defs=__BEGIN_DECLS&amp;project=core" class="intelliWindow-symbol" data-definition-place="undefined-in-file">__BEGIN_DECLS</a>
<a class="l" name="43" href="#43">43</a><span class='fold-space'>&nbsp;</span>#  <b>ifdef</b> <a href="/source/s?defs=__cplusplus&amp;project=core" class="intelliWindow-symbol" data-definition-place="undefined-in-file">__cplusplus</a>
<a class="l" name="44" href="#44">44</a><span class='fold-space'>&nbsp;</span>#    <b>define</b> <a href="/source/s?refs=__BEGIN_DECLS&amp;project=core" class="xm intelliWindow-symbol" data-definition-place="def">__BEGIN_DECLS</a> <b>extern</b> <span class="s">"C"</span> &#123;
<a class="l" name="45" href="#45">45</a><span class='fold-space'>&nbsp;</span>#  <b>else</b>
<a class="l" name="46" href="#46">46</a><span class='fold-space'>&nbsp;</span>#    <b>define</b> <a href="/source/s?refs=__BEGIN_DECLS&amp;project=core" class="xm intelliWindow-symbol" data-definition-place="def">__BEGIN_DECLS</a>
<a class="l" name="47" href="#47">47</a><span class='fold-space'>&nbsp;</span>#  <b>endif</b>
<a class="l" name="48" href="#48">48</a><span class='fold-space'>&nbsp;</span>#<b>endif</b>
<a class="l" name="49" href="#49">49</a><span class='fold-space'>&nbsp;</span>
<a class="hl" name="50" href="#50">50</a><span class='fold-space'>&nbsp;</span>#<b>ifndef</b> <a href="/source/s?defs=__END_DECLS&amp;project=core" class="intelliWindow-symbol" data-definition-place="undefined-in-file">__END_DECLS</a>
<a class="l" name="51" href="#51">51</a><span class='fold-space'>&nbsp;</span>#  <b>ifdef</b> <a href="/source/s?defs=__cplusplus&amp;project=core" class="intelliWindow-symbol" data-definition-place="undefined-in-file">__cplusplus</a>
<a class="l" name="52" href="#52">52</a><span class='fold-space'>&nbsp;</span>#    <b>define</b> <a href="/source/s?refs=__END_DECLS&amp;project=core" class="xm intelliWindow-symbol" data-definition-place="def">__END_DECLS</a> &#125;
<a class="l" name="53" href="#53">53</a><span class='fold-space'>&nbsp;</span>#  <b>else</b>
<a class="l" name="54" href="#54">54</a><span class='fold-space'>&nbsp;</span>#    <b>define</b> <a href="/source/s?refs=__END_DECLS&amp;project=core" class="xm intelliWindow-symbol" data-definition-place="def">__END_DECLS</a>
<a class="l" name="55" href="#55">55</a><span class='fold-space'>&nbsp;</span>#  <b>endif</b>
<a class="l" name="56" href="#56">56</a><span class='fold-space'>&nbsp;</span>#<b>endif</b>
<a class="l" name="57" href="#57">57</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="58" href="#58">58</a><span class='fold-space'>&nbsp;</span><span class="c">/* TODO: replace references to this. */</span>
<a class="l" name="59" href="#59">59</a><span class='fold-space'>&nbsp;</span>#<b>define</b> <a class="xm" name="HAVE_WIN32_IPC"/><a href="/source/s?refs=HAVE_WIN32_IPC&amp;project=core" class="xm intelliWindow-symbol" data-definition-place="def">HAVE_WIN32_IPC</a>
<a class="hl" name="60" href="#60">60</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="61" href="#61">61</a><span class='fold-space'>&nbsp;</span>#<b>ifdef</b> <a href="/source/s?defs=__CYGWIN__&amp;project=core" class="intelliWindow-symbol" data-definition-place="undefined-in-file">__CYGWIN__</a>
<a class="l" name="62" href="#62">62</a><span class='fold-space'>&nbsp;</span>#<a href="/source/s?defs=error&amp;project=core" class="intelliWindow-symbol" data-definition-place="undefined-in-file">error</a> <span class="s">"CYGWIN is unsupported for platform builds"</span>
<a class="l" name="63" href="#63">63</a><span class='fold-space'>&nbsp;</span>#<b>endif</b>
<a class="l" name="64" href="#64">64</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="65" href="#65">65</a><span class='fold-space'>&nbsp;</span><span class="c">/*
<a class="l" name="66" href="#66">66</a><span class='fold-space'>&nbsp;</span> * Define this if you build against MSVCRT.DLL
<a class="l" name="67" href="#67">67</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="68" href="#68">68</a><span class='fold-space'>&nbsp;</span>#<b>define</b> <a class="xm" name="HAVE_MS_C_RUNTIME"/><a href="/source/s?refs=HAVE_MS_C_RUNTIME&amp;project=core" class="xm intelliWindow-symbol" data-definition-place="def">HAVE_MS_C_RUNTIME</a>
<a class="l" name="69" href="#69">69</a><span class='fold-space'>&nbsp;</span>
<a class="hl" name="70" href="#70">70</a><span class='fold-space'>&nbsp;</span><span class="c">/*
<a class="l" name="71" href="#71">71</a><span class='fold-space'>&nbsp;</span> * Define this if we want to use WinSock.
<a class="l" name="72" href="#72">72</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="73" href="#73">73</a><span class='fold-space'>&nbsp;</span>#<b>define</b> <a class="xm" name="HAVE_WINSOCK"/><a href="/source/s?refs=HAVE_WINSOCK&amp;project=core" class="xm intelliWindow-symbol" data-definition-place="def">HAVE_WINSOCK</a>
<a class="l" name="74" href="#74">74</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="75" href="#75">75</a><span class='fold-space'>&nbsp;</span><span class="c">/*
<a class="l" name="76" href="#76">76</a><span class='fold-space'>&nbsp;</span> * We need to choose between 32-bit and 64-bit off_t.  All of our code should
<a class="l" name="77" href="#77">77</a><span class='fold-space'>&nbsp;</span> * agree on the same size.  For desktop systems, use 64-bit values,
<a class="l" name="78" href="#78">78</a><span class='fold-space'>&nbsp;</span> * because some of our libraries (e.g. wxWidgets) expect to be built that way.
<a class="l" name="79" href="#79">79</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="hl" name="80" href="#80">80</a><span class='fold-space'>&nbsp;</span>#<b>define</b> <a href="/source/s?refs=_FILE_OFFSET_BITS&amp;project=core" class="xm intelliWindow-symbol" data-definition-place="def">_FILE_OFFSET_BITS</a> <span class="n">64</span>
<a class="l" name="81" href="#81">81</a><span class='fold-space'>&nbsp;</span>#<b>define</b> <a href="/source/s?refs=_LARGEFILE_SOURCE&amp;project=core" class="xm intelliWindow-symbol" data-definition-place="def">_LARGEFILE_SOURCE</a> <span class="n">1</span>
<a class="l" name="82" href="#82">82</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="83" href="#83">83</a><span class='fold-space'>&nbsp;</span><span class="c">/*
<a class="l" name="84" href="#84">84</a><span class='fold-space'>&nbsp;</span> * Add any extra platform-specific defines here.
<a class="l" name="85" href="#85">85</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="86" href="#86">86</a><span class='fold-space'>&nbsp;</span>#<b>define</b> <a class="xm" name="WIN32"/><a href="/source/s?refs=WIN32&amp;project=core" class="xm intelliWindow-symbol" data-definition-place="def">WIN32</a> <span class="n">1</span>                 <span class="c">/* stock Cygwin doesn't define these */</span>
<a class="l" name="87" href="#87">87</a><span class='fold-space'>&nbsp;</span>#<b>define</b> <a href="/source/s?refs=_WIN32&amp;project=core" class="xm intelliWindow-symbol" data-definition-place="def">_WIN32</a> <span class="n">1</span>
<a class="l" name="88" href="#88">88</a><span class='fold-space'>&nbsp;</span>#<b>define</b> <a href="/source/s?refs=_WIN32_WINNT&amp;project=core" class="xm intelliWindow-symbol" data-definition-place="def">_WIN32_WINNT</a> <span class="n">0x0500</span>     <span class="c">/* admit to using &gt;= Win2K */</span>
<a class="l" name="89" href="#89">89</a><span class='fold-space'>&nbsp;</span>
<a class="hl" name="90" href="#90">90</a><span class='fold-space'>&nbsp;</span>#<b>define</b> <a class="xm" name="HAVE_WINDOWS_PATHS"/><a href="/source/s?refs=HAVE_WINDOWS_PATHS&amp;project=core" class="xm intelliWindow-symbol" data-definition-place="def">HAVE_WINDOWS_PATHS</a>      <span class="c">/* needed by simulator */</span>
<a class="l" name="91" href="#91">91</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="92" href="#92">92</a><span class='fold-space'>&nbsp;</span><span class="c">/*
<a class="l" name="93" href="#93">93</a><span class='fold-space'>&nbsp;</span> * The default path separator for the platform
<a class="l" name="94" href="#94">94</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="95" href="#95">95</a><span class='fold-space'>&nbsp;</span>#<b>define</b> <a class="xm" name="OS_PATH_SEPARATOR"/><a href="/source/s?refs=OS_PATH_SEPARATOR&amp;project=core" class="xm intelliWindow-symbol" data-definition-place="def">OS_PATH_SEPARATOR</a> <span class="s">'\\'</span>
<a class="l" name="96" href="#96">96</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="97" href="#97">97</a><span class='fold-space'>&nbsp;</span><span class="c">/*
<a class="l" name="98" href="#98">98</a><span class='fold-space'>&nbsp;</span> * Various definitions missing in MinGW
<a class="l" name="99" href="#99">99</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="hl" name="100" href="#100">100</a><span class='fold-space'>&nbsp;</span>#<b>ifdef</b> <a href="/source/s?defs=USE_MINGW&amp;project=core" class="intelliWindow-symbol" data-definition-place="undefined-in-file">USE_MINGW</a>
<a class="l" name="101" href="#101">101</a><span class='fold-space'>&nbsp;</span>#<b>define</b> <a class="xm" name="S_IRGRP"/><a href="/source/s?refs=S_IRGRP&amp;project=core" class="xm intelliWindow-symbol" data-definition-place="def">S_IRGRP</a> 0
<a class="l" name="102" href="#102">102</a><span class='fold-space'>&nbsp;</span>#<b>endif</b>
<a class="l" name="103" href="#103">103</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="104" href="#104">104</a><span class='fold-space'>&nbsp;</span>#<b>endif</b> <span class="c">/*_ANDROID_CONFIG_H*/</span>
<a class="l" name="105" href="#105">105</a><span class='fold-space'>&nbsp;</span>