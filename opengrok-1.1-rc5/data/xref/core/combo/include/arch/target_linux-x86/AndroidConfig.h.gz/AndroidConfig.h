<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Macro","xm",[["HAVE_ANDROID_OS",29],["HAVE_MALLOC_H",24],["HAVE_STDINT_H",39],["OS_PATH_SEPARATOR",34],["_ANDROID_CONFIG_H",7]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class='fold-space'>&nbsp;</span><span class="c">/*
<a class="l" name="2" href="#2">2</a><span class='fold-space'>&nbsp;</span> * Copyright 2005 The Android Open Source Project
<a class="l" name="3" href="#3">3</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="4" href="#4">4</a><span class='fold-space'>&nbsp;</span> * Android config -- "target_linux-x86".  Used for x86 linux target devices.
<a class="l" name="5" href="#5">5</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="6" href="#6">6</a><span class='fold-space'>&nbsp;</span>#<b>ifndef</b> <a class="d intelliWindow-symbol" href="#_ANDROID_CONFIG_H" data-definition-place="defined-in-file">_ANDROID_CONFIG_H</a>
<a class="l" name="7" href="#7">7</a><span class='fold-space'>&nbsp;</span>#<b>define</b> <a href="/source/s?refs=_ANDROID_CONFIG_H&amp;project=core" class="xm intelliWindow-symbol" data-definition-place="def">_ANDROID_CONFIG_H</a>
<a class="l" name="8" href="#8">8</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="9" href="#9">9</a><span class='fold-space'>&nbsp;</span><span class="c">/*
<a class="hl" name="10" href="#10">10</a><span class='fold-space'>&nbsp;</span> * ===========================================================================
<a class="l" name="11" href="#11">11</a><span class='fold-space'>&nbsp;</span> *                              !!! IMPORTANT !!!
<a class="l" name="12" href="#12">12</a><span class='fold-space'>&nbsp;</span> * ===========================================================================
<a class="l" name="13" href="#13">13</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="14" href="#14">14</a><span class='fold-space'>&nbsp;</span> * This file is included by ALL C/C++ source files.  Don't put anything in
<a class="l" name="15" href="#15">15</a><span class='fold-space'>&nbsp;</span> * here unless you are absolutely certain it can't go anywhere else.
<a class="l" name="16" href="#16">16</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="17" href="#17">17</a><span class='fold-space'>&nbsp;</span> * Any C++ stuff must be wrapped with "#ifdef __cplusplus".  Do not use "//"
<a class="l" name="18" href="#18">18</a><span class='fold-space'>&nbsp;</span> * comments.
<a class="l" name="19" href="#19">19</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="hl" name="20" href="#20">20</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="21" href="#21">21</a><span class='fold-space'>&nbsp;</span><span class="c">/*
<a class="l" name="22" href="#22">22</a><span class='fold-space'>&nbsp;</span> * Define if we have &lt;<a href="/source/s?path=malloc.h&amp;project=core">malloc.h</a>&gt; header
<a class="l" name="23" href="#23">23</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="24" href="#24">24</a><span class='fold-space'>&nbsp;</span>#<b>define</b> <a class="xm" name="HAVE_MALLOC_H"/><a href="/source/s?refs=HAVE_MALLOC_H&amp;project=core" class="xm intelliWindow-symbol" data-definition-place="def">HAVE_MALLOC_H</a> <span class="n">1</span>
<a class="l" name="25" href="#25">25</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="26" href="#26">26</a><span class='fold-space'>&nbsp;</span><span class="c">/*
<a class="l" name="27" href="#27">27</a><span class='fold-space'>&nbsp;</span> * Define if we're running on *our* linux on device or emulator.
<a class="l" name="28" href="#28">28</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="29" href="#29">29</a><span class='fold-space'>&nbsp;</span>#<b>define</b> <a class="xm" name="HAVE_ANDROID_OS"/><a href="/source/s?refs=HAVE_ANDROID_OS&amp;project=core" class="xm intelliWindow-symbol" data-definition-place="def">HAVE_ANDROID_OS</a> <span class="n">1</span>
<a class="hl" name="30" href="#30">30</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="31" href="#31">31</a><span class='fold-space'>&nbsp;</span><span class="c">/*
<a class="l" name="32" href="#32">32</a><span class='fold-space'>&nbsp;</span> * The default path separator for the platform
<a class="l" name="33" href="#33">33</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="34" href="#34">34</a><span class='fold-space'>&nbsp;</span>#<b>define</b> <a class="xm" name="OS_PATH_SEPARATOR"/><a href="/source/s?refs=OS_PATH_SEPARATOR&amp;project=core" class="xm intelliWindow-symbol" data-definition-place="def">OS_PATH_SEPARATOR</a> <span class="s">'/'</span>
<a class="l" name="35" href="#35">35</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="36" href="#36">36</a><span class='fold-space'>&nbsp;</span><span class="c">/*
<a class="l" name="37" href="#37">37</a><span class='fold-space'>&nbsp;</span> * Define if &lt;<a href="/source/s?path=stdint.h&amp;project=core">stdint.h</a>&gt; exists.
<a class="l" name="38" href="#38">38</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="39" href="#39">39</a><span class='fold-space'>&nbsp;</span>#<b>define</b> <a class="xm" name="HAVE_STDINT_H"/><a href="/source/s?refs=HAVE_STDINT_H&amp;project=core" class="xm intelliWindow-symbol" data-definition-place="def">HAVE_STDINT_H</a> <span class="n">1</span>
<a class="hl" name="40" href="#40">40</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="41" href="#41">41</a><span class='fold-space'>&nbsp;</span>#<b>endif</b> <span class="c">/* _ANDROID_CONFIG_H */</span>
<a class="l" name="42" href="#42">42</a><span class='fold-space'>&nbsp;</span>